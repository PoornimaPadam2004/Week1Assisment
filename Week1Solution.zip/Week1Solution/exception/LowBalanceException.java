package Week1Assgn.exception;

public class LowBalanceException extends Exception {
    public LowBalanceException(String message) {
        super(message);
    }
}