package Week1Assgn.model;

public enum AccountType {
	SAVINGS, CURRENT;

}
