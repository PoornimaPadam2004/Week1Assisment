package Week1Assgn.ui;

import Week1Assgn.exception.*;
import Week1Assgn.model.Account;
import Week1Assgn.model.AccountType;
import Week1Assgn.service.AccountService;

public class AccountTest {

    public static void main(String[] args) {
        try {
            AccountService accountService = new AccountService();

            Account acc1 = new Account(1001, "Poori", AccountType.SAVINGS, 1500f);
            Account acc2 = new Account(1002, "Poori", AccountType.CURRENT, 6000f);

            accountService.accountList.add(acc1);
            accountService.accountList.add(acc2);

            System.out.println("Balance of account 1001: " + accountService.getBalance(1001));

            accountService.deposit(1001, 500f);
            System.out.println("Balance of account 1001 after deposit: " + accountService.getBalance(1001));

            accountService.withdraw(1001, 700f);
            System.out.println("Balance of account 1001 after withdrawal: " + accountService.getBalance(1001));

        } catch (AccountNotFoundException | InvalidAmountException | InsufficientFundsException | LowBalanceException e) {
            System.out.println(e.getMessage());
        }
    
    }
}